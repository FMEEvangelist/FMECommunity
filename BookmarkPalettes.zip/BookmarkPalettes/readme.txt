Palettes
These palettes define colours to be used in FME Workbench bookmarks.
- <Name>Palette.json: A palette with the actual colours
- <Name>LightPalette.json: A palette where colours in light mode are lighted by about 20%

Palette Colours
- Art: Each palette represents an artwork. Each colour is one used in that work of art
- Sports: Each palette represents a sport. Each colour represents the main colour in a team's jersey or logo
- General: These are general palettes that don't fall under any particular category

To Install
- In FME Workbench select Tools > Options from the menubar
- Click on the menu option for Appearance
- Under Bookmark Options click on the Import Button
- Select the JSON file for your chosen bookmark palette

Palette Sources
- Palette Source: http://colorlisa.com/
- Palette Source: https://teamcolors.jim-nielsen.com/

Colour Names
- Colour Names: https://icolorpalette.com/
- Colour Lightening: https://mdigi.tools/lighten-color

These palettes are free to use within FME. If you create your own palette of colours, please feel free to submit them to the GitHub repository too. Let me know if you have ideas for other colour palettes.

mark.ireland@safe.com
